const passport = require('passport');

const FacebookStrategy = require('passport-facebook').Strategy;

passport.use(new FacebookStrategy({
    clientID: "878780773066741",
    clientSecret: "3c89fe49d2304ae6701aa054469a4c0e",
    callbackURL: "http://localhost:5000/auth/facebook/callback",
    //passReqToCallback : true
    profileFields: ['id', 'displayName', 'name', 'gender', 'picture.type(large)', 'email']
  },
  function(accessToken, refreshToken, profile, done) {
   // User.findOrCreate({ facebookId: profile.id }, function (err, user) {
    //  return done(null, user);
//   });
      console.log(profile)
      return done(null,profile)
  }
));


passport.serializeUser(function(user, done) 
{
    done(null, user);
})


passport.deserializeUser(function(user, done) 
{
    done(null, user);
})
