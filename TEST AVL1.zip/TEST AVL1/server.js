/*if(process.env.NODE_ENV !=='production')
{
   require('dotenv').config()
}*/

const express = require('express')
const app = express()

const bcrypt=require('bcrypt')
const passport = require('passport')
const flash = require('express-flash')
const session = require('express-session')
const session1 = require('express-session')
const methodOverride = require('method-override')

require('./google');
require('./facebook');


const initializePassport = require('./passport-config')
initializePassport(
    passport, 
    email => users.find(user =>user.email === email),
    id => users.find(user => user.id === id)
    
)


const users=[]

app.set('view-engine', 'ejs')
app.use(express.urlencoded({extended:false}))
app.use(flash())

app.use(session(
{
    //secret: process.env.SESSION_SECRET,
    secret:'cat',
    resave: false,
    saveUninitialized:true,
    cookie: {}    
}
))


app.use(passport.initialize())
app.use(passport.session())
app.use(methodOverride('_method'))

   


app.get('/email',(req,resp) => 
{
   resp.render('email.ejs',{name: req.user.name})
    //resp.redirect('https://www.youtube.com/hashtag/youtubedashboard')
     
})

app.get('/login',(req,resp) => 
{
    resp.render('login.ejs')
})


app.post('/login', passport.authenticate('local', {
    successRedirect: '/email',
    failureRedirect: '/login',
    failureflash: true
}))


app.get('/register',(req,resp) => 
{
    resp.render('register.ejs')
})

app.post('/register',async(req,resp) =>
{
   try 
   {
       const hashedPassword = await bcrypt.hash(req.body.password,8)
       users.push(
       {
         id: Date.now().toString(),
         name: req.body.name,
         email: req.body.email,
         password: hashedPassword
       })
       resp.redirect('/login')
   }
   catch 
   {
      resp.redirect('/register')
   }
   console.log(users)
})


app.delete('/logout', (req, resp) =>   
{
   req.logOut();
   resp.redirect('/login')
}
);

function isLoggedIn(req,resp, next)
{
    req.user ? next() : resp.sendStatus(401);
}

app.get('/google', (req,resp) =>
{
    resp.render('google.ejs')
    // resp.send('<a href="/auth/google">Authenticate with google</a>')
}
);

app.get('/auth/google', passport.authenticate('google',{scope: ['email', 'profile']}));

app.get('/auth/google/callback',
   passport.authenticate('google',
   {
      successRedirect: '/auth/protected',
      failureRedirect: '/auth/failure'       
   }
   )
);

app.get('/auth/failure', (req,resp) => 
{
   resp.send('something went wrong !')
}
);

app.get('/auth/protected', isLoggedIn, (req,resp) => 
{
     // resp.render('index.ejs',{name: req.user.name})
    resp.send(`hello  ${req.user.displayName}`)
   // resp.redirect('https://www.youtube.com/hashtag/youtubedashboard');

}
);

app.get('/google_logout', (req,resp)=> 
{
   req.logOut();
   req.session.destroy(); 
   resp.redirect('/google');
   
}
);

app.get('/facebook',(req,resp) =>
{
    resp.render('fb.ejs')
}
)

app.get('/auth/facebook', passport.authenticate('facebook',{scope: 'email'}));

app.get('/auth/facebook/callback', passport.authenticate('facebook',
{
    successRedirect: '/auth/profile',
    failureRedirect: '/auth/failed'
}
));

app.get('/auth/profile',isLoggedIn, (req,resp) => 
{
   // resp.send(`hello  ${req.user.displayName}`)
    resp.send('Welcome to facebook')
})

app.get('/auth/failed',(req,resp) => 
{
    
    resp.send('Invalid user')
})

app.get('/facebook_logout', (req,resp)=> 
{
   req.logOut();
   req.session.destroy();
    
   resp.redirect('/facebook');
   
}
);



app.listen(5000)
